// ═══════════════════════════════════════════════════════════════
//  WORKSHOP REGISTRATION — Google Apps Script
//  Paste this entire file into your Apps Script editor and deploy
//  as a Web App (Execute as: Me, Access: Anyone)
// ═══════════════════════════════════════════════════════════════

// ─── CONFIGURATION ─────────────────────────────────────────────
const SHEET_NAME   = 'Registrations';   // tab name in your Google Sheet
const EVENT_NAME   = 'Workshop 2025';
const EVENT_DATE   = 'TBD 2025';        // e.g. "14 June 2025"
const EVENT_VENUE  = 'Venue TBD';       // e.g. "Main Auditorium"
const TICKET_PREFIX = 'WKSHP';

// Column indices (0-based) — match your sheet exactly
const COL = {
  TIMESTAMP:   0,
  NAME:        1,
  EMAIL:       2,
  PHONE:       3,
  ORG:         4,
  TICKET_ID:   5,
  STATUS:      6,
  CHECKIN_TIME: 7,
  CHECKED_BY:  8,
};

// ─── CORS HELPER ────────────────────────────────────────────────
function corsOutput(data) {
  const output = ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
  return output;
}

// ─── doGet — ticket lookup for scanner ─────────────────────────
function doGet(e) {
  try {
    const ticketId = (e.parameter.ticketId || '').trim().toUpperCase();
    if (!ticketId) return corsOutput({ found: false, error: 'No ticketId provided' });

    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    const data  = sheet.getDataRange().getValues();

    // Row 0 is header; search from row 1
    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (String(row[COL.TICKET_ID]).trim().toUpperCase() === ticketId) {
        return corsOutput({
          found:       true,
          name:        row[COL.NAME],
          email:       row[COL.EMAIL],
          phone:       row[COL.PHONE],
          org:         row[COL.ORG],
          ticketId:    row[COL.TICKET_ID],
          checkedIn:   row[COL.STATUS],
          checkinTime: row[COL.CHECKIN_TIME] ? String(row[COL.CHECKIN_TIME]) : '',
          checkedBy:   row[COL.CHECKED_BY],
        });
      }
    }

    return corsOutput({ found: false });
  } catch (err) {
    return corsOutput({ found: false, error: err.message });
  }
}

// ─── doPost — register or checkin ──────────────────────────────
function doPost(e) {
  try {
    const body   = JSON.parse(e.postData.contents);
    const action = body.action;

    if (action === 'register') {
      return handleRegister(body);
    } else if (action === 'checkin') {
      return handleCheckin(body);
    } else {
      return corsOutput({ success: false, message: 'Unknown action' });
    }
  } catch (err) {
    return corsOutput({ success: false, message: err.message });
  }
}

// ─── REGISTER ───────────────────────────────────────────────────
function handleRegister(body) {
  const { name, email, phone, org, eventName, eventDate, eventVenue } = body;

  if (!name || !email || !phone || !org) {
    return corsOutput({ success: false, message: 'Missing required fields' });
  }

  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);

  // Generate next ticket ID
  const lastRow   = sheet.getLastRow();
  const count     = Math.max(lastRow, 1); // at least 1 so WKSHP-0001 is first
  const ticketNum = String(count).padStart(4, '0');
  const ticketId  = `${TICKET_PREFIX}-${ticketNum}`;

  const timestamp = new Date();

  // Append row
  sheet.appendRow([
    timestamp,
    name,
    email,
    phone,
    org,
    ticketId,
    'Not Yet',  // Check-in Status default
    '',          // Check-in Time
    '',          // Checked In By
  ]);

  // Send email
  const finalEventName  = eventName  || EVENT_NAME;
  const finalEventDate  = eventDate  || EVENT_DATE;
  const finalEventVenue = eventVenue || EVENT_VENUE;

  sendTicketEmail(email, name, ticketId, finalEventName, finalEventDate, finalEventVenue);

  return corsOutput({ success: true, ticketId });
}

// ─── CHECK IN ───────────────────────────────────────────────────
function handleCheckin(body) {
  const { ticketId, volunteerName } = body;
  if (!ticketId) return corsOutput({ success: false, message: 'Missing ticketId' });

  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const data  = sheet.getDataRange().getValues();

  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (String(row[COL.TICKET_ID]).trim().toUpperCase() === ticketId.trim().toUpperCase()) {

      if (String(row[COL.STATUS]).trim() === 'Yes') {
        return corsOutput({
          success:  false,
          reason:   'already_checked_in',
          time:     String(row[COL.CHECKIN_TIME]),
          by:       row[COL.CHECKED_BY],
        });
      }

      // Update the sheet (sheet rows are 1-indexed)
      const sheetRow = i + 1;
      sheet.getRange(sheetRow, COL.STATUS + 1).setValue('Yes');
      sheet.getRange(sheetRow, COL.CHECKIN_TIME + 1).setValue(new Date().toLocaleString());
      sheet.getRange(sheetRow, COL.CHECKED_BY + 1).setValue(volunteerName || 'Volunteer');

      return corsOutput({ success: true });
    }
  }

  return corsOutput({ success: false, reason: 'not_found', message: 'Ticket ID not found' });
}

// ─── EMAIL ──────────────────────────────────────────────────────
function sendTicketEmail(email, name, ticketId, eventName, eventDate, eventVenue) {
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(ticketId)}&color=000000&bgcolor=ffffff`;

  const htmlBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background:#f0f0f5;font-family:'Helvetica Neue',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f0f5;padding:32px 16px;">
    <tr><td align="center">
      <table width="520" cellpadding="0" cellspacing="0" style="max-width:520px;width:100%;">

        <!-- Header -->
        <tr>
          <td style="background:linear-gradient(135deg,#6c63ff,#8b5cf6);border-radius:16px 16px 0 0;padding:32px 32px 28px;text-align:center;">
            <p style="margin:0 0 8px;font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.6);">✦ Official Entry Pass</p>
            <h1 style="margin:0;font-size:26px;font-weight:800;color:#fff;line-height:1.15;">${eventName}</h1>
            <p style="margin:10px 0 0;font-size:13px;color:rgba(255,255,255,.75);">${eventDate} &nbsp;·&nbsp; ${eventVenue}</p>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="background:#ffffff;padding:28px 32px;">
            <p style="margin:0 0 20px;font-size:15px;color:#333;">Hello <strong>${name}</strong>,</p>
            <p style="margin:0 0 24px;font-size:14px;color:#555;line-height:1.6;">
              Your registration is confirmed! Please find your ticket below. Present this QR code at the entrance for check-in.
            </p>

            <!-- Ticket box -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0f;border-radius:14px;overflow:hidden;margin-bottom:24px;">
              <tr>
                <td style="padding:22px 24px 18px;">
                  <p style="margin:0 0 16px;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#7a7a9a;">Your Ticket</p>
                  <table width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                      <td valign="top" style="width:110px;">
                        <img src="${qrUrl}" width="100" height="100" alt="QR Code" style="display:block;border-radius:8px;" />
                      </td>
                      <td valign="top" style="padding-left:18px;">
                        <p style="margin:0 0 2px;font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:#7a7a9a;">Ticket ID</p>
                        <p style="margin:0 0 12px;font-size:22px;font-weight:800;color:#f5c842;letter-spacing:.04em;">${ticketId}</p>
                        <p style="margin:0 0 2px;font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:#7a7a9a;">Name</p>
                        <p style="margin:0 0 10px;font-size:14px;color:#e8e8f0;font-weight:500;">${name}</p>
                        <p style="margin:0 0 2px;font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:#7a7a9a;">Status</p>
                        <p style="margin:0;font-size:13px;color:#3dd68c;font-weight:600;">✓ Registered</p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>

            <p style="margin:0 0 8px;font-size:13px;color:#555;line-height:1.6;">
              📌 Save this email or take a screenshot of the QR code to present at the venue.
            </p>
            <p style="margin:0;font-size:13px;color:#555;line-height:1.6;">
              We look forward to seeing you at <strong>${eventName}</strong>!
            </p>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background:#f7f7fb;border-radius:0 0 16px 16px;padding:18px 32px;text-align:center;">
            <p style="margin:0;font-size:11px;color:#aaa;">This is an automated ticket confirmation. Do not reply to this email.</p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>
  `;

  MailApp.sendEmail({
    to:       email,
    subject:  `Your Ticket for ${eventName} — ${ticketId}`,
    htmlBody: htmlBody,
  });
}
